package com.cg.hostel.exception;

public class HostelException extends Exception {

	public HostelException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HostelException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public HostelException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public HostelException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public HostelException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
