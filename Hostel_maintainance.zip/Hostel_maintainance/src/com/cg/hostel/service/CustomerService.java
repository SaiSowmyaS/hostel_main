package com.cg.hostel.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.hostel.bean.CustomerBean;
import com.cg.hostel.bean.HostelBean;
import com.cg.hostel.exception.CustomerException;
import com.cg.hostel.exception.HostelException;

public interface CustomerService {
	public String registerHostel(HostelBean hostel) throws HostelException;
	public List viewHostel() throws CustomerException;
	public String addCustomer(CustomerBean customer) throws CustomerException;
	public CustomerBean viewCustomerDetails(String roomNumber) throws CustomerException, SQLException;
	public List retrieveAll() throws CustomerException;
	public HostelBean getHostelName(String allocate) throws HostelException, SQLException;

}
