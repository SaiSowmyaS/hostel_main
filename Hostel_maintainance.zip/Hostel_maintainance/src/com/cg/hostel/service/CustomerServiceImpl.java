package com.cg.hostel.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.hostel.bean.CustomerBean;
import com.cg.hostel.bean.HostelBean;
import com.cg.hostel.dao.CustomerDao;
import com.cg.hostel.dao.CustomerDaoImpl;
import com.cg.hostel.exception.CustomerException;
import com.cg.hostel.exception.HostelException;

public class CustomerServiceImpl implements CustomerService {
	CustomerDao customerDao=new CustomerDaoImpl();

	@Override
	public List viewHostel() throws CustomerException {
		// TODO Auto-generated method stub
		customerDao=new CustomerDaoImpl();
		List<HostelBean>hostelList=null;
		hostelList=customerDao.viewHostel();
		return hostelList;
	}

	@Override
	public String addCustomer(CustomerBean customer) throws CustomerException {
		// TODO Auto-generated method stub
		String roomSeq;
		roomSeq=customerDao.addCustomer(customer);
		return roomSeq;
	}

	@Override
	public CustomerBean viewCustomerDetails(String roomNumber) throws CustomerException, SQLException {
		// TODO Auto-generated method stub
		System.out.println(roomNumber);
		CustomerBean customerBean=new CustomerBean();
		customerBean=customerDao.viewCustomerDetails(roomNumber);
		return customerBean;
	}

	@Override
	public List retrieveAll() throws CustomerException {
		// TODO Auto-generated method stub
		customerDao=new CustomerDaoImpl();
		List<CustomerBean> customerList=null;
		customerList=customerDao.retrieveAll();
		return customerList;
	}

	public boolean validateCustomer(CustomerBean customer) {
		// TODO Auto-generated method stub
		List<String> validationErrors=new ArrayList<String>();
		if(!(isValidName(customer.getCustomerName())))
		{
			validationErrors.add("\n Customer Name should be in alphabets and in minimum 4 characters long!\n");
		}
		if(!(isValidPhoneNumber(customer.getPhoneNumber())))
		{
			validationErrors.add("\nphone number should be in 10 digits");
		}
		if(!(isValidAddress(customer.getAddress())))
		{
			validationErrors.add("\n Address should be greater than 5 characters!\n");
		}
		if(!(isValidGraudianName(customer.getGraudianName())))
		{
			validationErrors.add("\nDonor name should be Alphabets and minimum 5 characters long!\n");
		}
		if(!validationErrors.isEmpty())
			return false;
		
		return true;
	}

	private boolean isValidGraudianName(String graudianName) {
		// TODO Auto-generated method stub
		Pattern namePattern=Pattern.compile("^[A-Za-z]{5,}$");
		Matcher nameMatcher=namePattern.matcher(graudianName);
		return nameMatcher.matches();
		
	}

	private boolean isValidAddress(String address) {
		// TODO Auto-generated method stub
		return (address.length() > 5);
		
	}

	private boolean isValidPhoneNumber(String phoneNumber) {
		// TODO Auto-generated method stub
		Pattern phonePattern=Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		return phoneMatcher.matches();
	}

	private boolean isValidName(String customerName) {
		// TODO Auto-generated method stub
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(customerName);
		return nameMatcher.matches();
	}

	@Override
	public String registerHostel(HostelBean hostel) throws HostelException {
		// TODO Auto-generated method stub
		String hosSeq;
		hosSeq=customerDao.registerHostel(hostel);
		return hosSeq;
		
	}

	@Override
	public HostelBean getHostelName(String allocate) throws HostelException, SQLException {
		// TODO Auto-generated method stub
		System.out.println(allocate);
		HostelBean hostelBean=new HostelBean();
		hostelBean=customerDao.getHostelName(allocate);
		return hostelBean;
		
	}

}
