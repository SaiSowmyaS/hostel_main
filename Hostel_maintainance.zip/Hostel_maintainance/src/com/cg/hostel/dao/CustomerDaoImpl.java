package com.cg.hostel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.hostel.bean.CustomerBean;
import com.cg.hostel.bean.HostelBean;
import com.cg.hostel.exception.CustomerException;
import com.cg.hostel.exception.HostelException;
import com.cg.hostel.util.DBConnection;

public class CustomerDaoImpl implements CustomerDao {
	
	@Override
	public String addCustomer(CustomerBean customer) throws CustomerException {
		// TODO Auto-generated method stub
		Connection connection=com.cg.hostel.util.DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String room_Number=null;
		int queryResult=0;
		try
		{
			preparedStatement=connection.prepareStatement("insert into Cust_Details values(roomnum_sequence.nextVal,?,?,?,?,SYSDATE)");
			preparedStatement.setString(1, customer.getCustomerName());
			preparedStatement.setString(2, customer.getPhoneNumber());
			preparedStatement.setString(3, customer.getAddress());
			preparedStatement.setString(4, customer.getGraudianName());
			preparedStatement.executeUpdate();
			Statement statement=null;
			statement=connection.createStatement();
			resultSet=statement.executeQuery("select max(roomNumber) from cust_details");
			while(resultSet.next())
			{
				room_Number=resultSet.getString(1);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		try {
			resultSet.close();
			preparedStatement.close();
			connection.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return room_Number;
	}

	@Override
	public CustomerBean viewCustomerDetails(String roomNumber) throws CustomerException, SQLException {
		// TODO Auto-generated method stub
		Connection connection=DBConnection.getConnection();
		ResultSet resultSet=null;
		Statement st=null;
		CustomerBean customerBean=new CustomerBean();
		st=connection.createStatement();
		resultSet=st.executeQuery("select * from cust_details where roomNumber="+roomNumber+"");
		while(resultSet.next())
		{
			customerBean.setRoomNumber(resultSet.getString(1));
			customerBean.setCustomerName(resultSet.getString(2));
			customerBean.setPhoneNumber(resultSet.getString(3));
			customerBean.setAddress(resultSet.getString(4));
			customerBean.setGraudianName(resultSet.getString(5));
			customerBean.setJoiningDate(resultSet.getDate(6));
			
		}
		return customerBean;
	}

	@Override
	public List retrieveAll() throws CustomerException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getConnection();
		int customerCount=0;
		PreparedStatement ps=null;
		ResultSet resultset = null;
		List<CustomerBean> customerList=new ArrayList<CustomerBean>();
		try
		{
			ps=con.prepareStatement("select * from cust_details");
			resultset=ps.executeQuery();
			while(resultset.next())
			{
				CustomerBean customerBean=new CustomerBean();
				customerBean.setRoomNumber(resultset.getString(1));
				customerBean.setCustomerName(resultset.getString(2));
				customerBean.setPhoneNumber(resultset.getString(3));
				customerBean.setAddress(resultset.getString(4));
				customerBean.setGraudianName(resultset.getString(5));
				customerBean.setJoiningDate(resultset.getDate(6));
				customerList.add(customerBean);
				customerCount++;
			}
			
		}
		catch(Exception e)
		{
			e.fillInStackTrace();
		}
		finally
		{
			try
			{
				resultset.close();
				ps.close();
				con.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		if(customerCount==0)
			return null;
		else
			return customerList;
	}

	@Override
	public String registerHostel(HostelBean hostel) throws HostelException {
		// TODO Auto-generated method stub
		Connection connection=com.cg.hostel.util.DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String nest_Id=null;
		int queryResult=0;
		try
		{
			preparedStatement=connection.prepareStatement("insert into nest_Details values(nestid_seq.nextVal,?,?,?,?)");
			preparedStatement.setString(1, hostel.getNestName());
			preparedStatement.setString(2, hostel.getNestLocation());
			preparedStatement.setString(3, hostel.getPhoneNumber());
			preparedStatement.setInt(4, hostel.getRent());
			preparedStatement.executeUpdate();
			Statement statement=null;
			statement=connection.createStatement();
			resultSet=statement.executeQuery("select max(nestid) from nest_details");
			while(resultSet.next())
			{
				nest_Id=resultSet.getString(1);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		try {
			resultSet.close();
			preparedStatement.close();
			connection.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return nest_Id;
		
	}

	@Override
	public List viewHostel() throws CustomerException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getConnection();
		int hostelCount=0;
		PreparedStatement ps=null;
		ResultSet resultset = null;
		List<HostelBean> hostelList=new ArrayList<HostelBean>();
		try
		{
			ps=con.prepareStatement("select * from nest_details");
			resultset=ps.executeQuery();
			while(resultset.next())
			{
				HostelBean hostelBean=new HostelBean();
				hostelBean.setNestId(resultset.getString(1));
				hostelBean.setNestName(resultset.getString(2));
				hostelBean.setNestLocation(resultset.getString(3));
				hostelBean.setPhoneNumber(resultset.getString(4));
				hostelBean.setRent(resultset.getInt(5));
				hostelList.add(hostelBean);
				hostelCount++;
				
			}
			
		}
		catch(Exception e)
		{
			e.fillInStackTrace();
		}
		finally
		{
			try
			{
				resultset.close();
				ps.close();
				con.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		if(hostelCount==0)
			return null;
		else
			return hostelList;
	
		
	}

	@Override
	public HostelBean getHostelName(String allocate) throws HostelException, SQLException {
		// TODO Auto-generated method stub
		Connection connection=DBConnection.getConnection();
		ResultSet resultSet=null;
		Statement st=null;
		HostelBean hostelBean=new HostelBean();
		st=connection.createStatement();
		resultSet=st.executeQuery("select * from nest_details where nestId="+allocate+"");
		while(resultSet.next())
		{
			hostelBean.setNestId(resultSet.getString(1));
			hostelBean.setNestName(resultSet.getString(2));
			hostelBean.setNestLocation(resultSet.getString(3));
			hostelBean.setPhoneNumber(resultSet.getString(4));
			hostelBean.setRent(resultSet.getInt(5));
			
			
		}
		return hostelBean;
		
	}

}
