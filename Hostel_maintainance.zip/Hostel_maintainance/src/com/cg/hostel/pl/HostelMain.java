package com.cg.hostel.pl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.hostel.bean.CustomerBean;
import com.cg.hostel.bean.HostelBean;
import com.cg.hostel.service.CustomerService;
import com.cg.hostel.service.CustomerServiceImpl;

public class HostelMain {
	static Scanner scanner=new Scanner(System.in);
	static CustomerService customerService=null;
	static CustomerServiceImpl customerServiceImpl=null;
	public static void main(String[] args) {
		CustomerBean customerBean=null;
		HostelBean hostelBean=null;
		String nestId=null;
		String roomNumber=null;
		String allocate=null;
		int option=0,choice=0;
		char loop;
		do {
			System.out.println("**********HOSTEL MANAGEMENT***********");
			System.out.println("1.Hostel Admin");
			System.out.println("2.Customer");
			System.out.println("3.Exit");
			System.out.println("Enter your Choice");
			choice=scanner.nextInt();
		
		switch(choice)
		{
		case 1:
			while(hostelBean==null)
			{
				hostelBean=populateHostelBean();
			}
			try {
				customerService=new CustomerServiceImpl();
				nestId=customerService.registerHostel(hostelBean);
				System.out.println("Hostel are Inserted Successfully!!!!!");
				System.out.println("Nest ID is "+nestId);
				
			}
			catch(Exception ce)
			{
				ce.printStackTrace();
			}
			finally
			{
				nestId=null;
				customerService=null;
				hostelBean=null;
			}
			break;
			
			
		
		case 2:
		 while(true)
		 {
			 System.out.println();
			 System.out.println();
			 System.out.println(" HOSTEL BOOKING ");
			 System.out.println("--------------------------");
			 System.out.println("1.Available Hostels");
			 System.out.println("2.Add Customer");
			 System.out.println("3.View Customer Details");
			 System.out.println("4.Retrieve All");
			 System.out.println("5.Exit");
			 System.out.println("---------------------------");
			 System.out.println("***************************");
			 System.out.println("---------------------------");
			 System.out.println("select the option");
			 try
			 {
				option=scanner.nextInt();
				switch(option)
				{
				case 1:
					customerService=new CustomerServiceImpl();
					try
					{
						List<HostelBean> hostelList=new ArrayList<HostelBean>();
						hostelList=customerService.viewHostel();
						if(hostelList!=null)
						{
							Iterator<HostelBean>j=hostelList.iterator();
							while(j.hasNext()) {
								System.out.println(j.next());
							}
						}
						else
						{
							
						}
						System.out.println("-----Choose your Nest----");
						System.out.println("Enter your nest ID that you wish to occupy ");
						allocate=scanner.next();
						hostelBean=customerService.getHostelName(allocate);
						System.out.println(hostelBean);
					}
				
					catch(Exception e)
					{
						e.getStackTrace();
					}
					hostelBean=null;
					
					
					break;
					
				case 2:
					while(customerBean==null)
					{
						customerBean=populateCustomerBean();
					}
					try {
						customerService=new CustomerServiceImpl();
						roomNumber=customerService.addCustomer(customerBean);
						System.out.println("Rooms Are Booked Successfully!!!!!");
						System.out.println("Room Number is "+roomNumber);
						
						
						
						
						   
						
					}
					catch(Exception ce)
					{
						ce.printStackTrace();
					}
					finally
					{
						roomNumber=null;
						customerService=null;
						customerBean=null;
					}
					break;
				
					
				case 3:
					System.out.println("Enter the Room Number to get details of that particular person");
					roomNumber=scanner.next();
					customerService=new CustomerServiceImpl();
					customerBean=customerService.viewCustomerDetails(roomNumber);
					System.out.println(customerBean);
					
					break;
					
				case 4:
					customerService=new CustomerServiceImpl();
					try
					{
						List<CustomerBean> customerList=new ArrayList<CustomerBean>();
						customerList=customerService.retrieveAll();
						if(customerList!=null)
						{
							Iterator<CustomerBean>i=customerList.iterator();
							while(i.hasNext()) {
								System.out.println(i.next());
							}
						}
						else
						{
							System.out.println("None Registered the Hostel");
						}
					}
					catch(Exception e)
					{
						e.getStackTrace();
					}
					
					break;
					
				
					
					default:
						System.out.println("Try Again!!!!!!!");
						System.exit(0);
						break;
				}
			 }
			 catch(Exception e)
			 {
				e.printStackTrace(); 
			 }
			 
		
	}
		 
		case 3:
			System.out.println("Application closed!!!!!");
			System.exit(0);
			break;
		 
		 default:
			 System.out.println("Pick Correct Choice");
			 break;
		}
		System.out.println("Do you want to continue(y/n): ");
		loop=scanner.next().toLowerCase().charAt(0);
		}while(loop=='y');
		scanner.close();

}
	private static HostelBean populateHostelBean() {
		// TODO Auto-generated method stub
		HostelBean hostelBean=new HostelBean();
		System.out.println("Enter the Nest Details");
		System.out.println("Enter the Nest Name");
		hostelBean.setNestName(scanner.next());
		System.out.println("Enter the Nest Location");
		hostelBean.setNestLocation(scanner.next());
		System.out.println("Enter the Nest Phone Number");
		hostelBean.setPhoneNumber(scanner.next());
		System.out.println("Enter the Nest Rent");
		hostelBean.setRent(scanner.nextInt());
		return hostelBean;
	}
	private static CustomerBean populateCustomerBean() {
		CustomerBean customerBean=new CustomerBean();
		System.out.println("Enter the Customer Details");
		System.out.println("Enter the Customer Name");
		customerBean.setCustomerName(scanner.next());
		System.out.println("Enter the Customer PhoneNumber");
		customerBean.setPhoneNumber(scanner.next());
		System.out.println("Enter the Customer Address");
		customerBean.setAddress(scanner.next());
		System.out.println("Enter the Graudian Name");
		customerBean.setGraudianName(scanner.next());
		customerServiceImpl=new CustomerServiceImpl();
		try
		{
			if(customerServiceImpl.validateCustomer(customerBean))
				return customerBean;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
		
	}


}
