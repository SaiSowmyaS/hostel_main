package com.cg.hostel.bean;

import java.util.Date;

public class CustomerBean {
	private String roomNumber;
	private String customerName;
	private String phoneNumber;
	private String Address;
	private String GraudianName;
	private Date joiningDate;
	public String getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getGraudianName() {
		return GraudianName;
	}
	public void setGraudianName(String graudianName) {
		GraudianName = graudianName;
	}
	public Date getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}
	@Override
	public String toString() {
		return "CustomerBean [roomNumber=" + roomNumber + ", customerName=" + customerName + ", phoneNumber="
				+ phoneNumber + ", Address=" + Address + ", GraudianName=" + GraudianName + ", joiningDate="
				+ joiningDate + "]";
	}
	

}
